setwd("C:\\Users\\USER\\Desktop\\IT24102645")

#Q1-i
#Binomial distribution with n=50 and p=0.85

#Q1-ii
1 - pbinom(46, 50, 0.85, lower.tail = TRUE)

#Q2-i
#Number of customer calls received in per hour

#Q2-ii
#Poisson distribution with lambda=12

#Q2-iii
dpois(15, 12)